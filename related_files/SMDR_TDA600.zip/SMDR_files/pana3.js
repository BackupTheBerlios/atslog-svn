var chap = null; 
function openCloseTOC(eid) { 
  eid.style.display = (eid.style.display == "none") ? "" : "none"; 
  chap = eid; 
  event.srcElement.scrollIntoView(); 
  return; 
} 
var selTOC = null; 
var origClassName = ""; 
function setSelectedTOC(eid) { 
  if (selTOC) { 
  	selTOC.className = origClassName; 
  } 
  selTOC = eid; 
  origClassName = eid.className; 
  eid.className = "toc-selected"; 
  return; 
} 
function openExfootnote(eid) { 
  var prop = "menubar=no,status=no,toolbar=no,resizable=yes,scrollbars=yes,"; 
  prop = prop + "left=200,top=200,width=350,height=100"; 
  var win = window.open("","",prop); 
  win.document.open(); 
  win.document.write("<head>"); 
  win.document.write("<META http-equiv='Content-Type' content='text/html; charset=windows-1252'>"); 
  win.document.write("<LINK REL='stylesheet' HREF='pana3.css' TYPE='text/css'>"); 
  win.document.write("<title>EXFOOTNOTE</title>"); 
  win.document.write("</head>"); 
  win.document.write("<body class=body-exfootnote>"); 
  win.document.write(eid.outerHTML); 
  win.document.write("</body>"); 
  win.document.close(); 
  win.focus(); 
} 
